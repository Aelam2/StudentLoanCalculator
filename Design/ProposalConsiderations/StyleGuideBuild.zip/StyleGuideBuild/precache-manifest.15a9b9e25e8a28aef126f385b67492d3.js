self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9523ecfb1a648c0350333713b4b64c98",
    "url": "./index.html"
  },
  {
    "revision": "8342aa50ecf8c5ee7d5b",
    "url": "./static/css/2.4b6e3ef2.chunk.css"
  },
  {
    "revision": "38407383dc8692379793",
    "url": "./static/css/main.5be2b042.chunk.css"
  },
  {
    "revision": "8342aa50ecf8c5ee7d5b",
    "url": "./static/js/2.996f7a0f.chunk.js"
  },
  {
    "revision": "1f0a7691723b8d205c0bd83f00663892",
    "url": "./static/js/2.996f7a0f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "38407383dc8692379793",
    "url": "./static/js/main.33c41304.chunk.js"
  },
  {
    "revision": "8ffa459b4a3452beb650",
    "url": "./static/js/runtime-main.8aa5386b.js"
  }
]);